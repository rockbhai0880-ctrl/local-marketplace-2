/* ══════════════════════════════════════════════
   ⭐ 1. CONFIG
   ══════════════════════════════════════════════ */
const SUPABASE_URL = 'https://ckojkrojfagagvbgjokg.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNrb2prcm9qZmFnYWd2Ymdqb2tnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4NTc2NDIsImV4cCI6MjEwNjQzMzY0Mn0.J0zCycV2QjxYRoG0e_6yJd191MECrD-cZJTlTA1cqTM';

(function () {
'use strict';
if (window.__SOKO_DATA_JS_LOADED) { console.warn('⚠️ data.js imeshapakiwa — inapuuzwa'); return; }
window.__SOKO_DATA_JS_LOADED = true;

/* ══════════════════════════════════════════════
   ⭐ 2. CACHE
   ══════════════════════════════════════════════ */
let PRODUCTS_CACHE = [];
let ORDERS_CACHE = [];
let REQUESTS_CACHE = [];
let USERS_CACHE = [];
let DATA_READY = false;

/* ⭐ SESSION SNAPSHOT — page-to-page navigation bila kuvuta upya */
const SNAP_KEY = 'sokoSnapshot_v1';
const USERS_KEY = 'sokoUsers_v1';
const USERS_TTL = 10 * 60 * 1000;          /* users hubadilika nadra — cache dakika 10 */
let INIT_RESOLVE = null;
const INIT_PROMISE = new Promise(function (res) { INIT_RESOLVE = res; });

function readSnapshot() {
    try {
        const s = sessionStorage.getItem(SNAP_KEY);
        return s ? JSON.parse(s) : null;
    } catch (e) { return null; }
}
function writeSnapshot() {
    try {
        const payload = JSON.stringify({
            t: Date.now(),
            products: PRODUCTS_CACHE,
            orders: ORDERS_CACHE,
            requests: REQUESTS_CACHE
        });
        if (payload.length > 3500000) {   /* quota ya sessionStorage ~5MB — usijaze */
            console.warn('⚠️ Snapshot kubwa mno — haijahifadhiwi (picha zingine zipo base64?)');
            return false;
        }
        sessionStorage.setItem(SNAP_KEY, payload);
        return true;
    } catch (e) { return false; }
}
function readUsersCache() {
    try {
        const s = localStorage.getItem(USERS_KEY);
        if (!s) return null;
        const u = JSON.parse(s);
        if (Date.now() - u.t > USERS_TTL) return null;
        return u.users || null;
    } catch (e) { return null; }
}
function writeUsersCache() {
    try {
        localStorage.setItem(USERS_KEY, JSON.stringify({ t: Date.now(), users: USERS_CACHE }));
    } catch (e) {}
}
function snapshotSignature() {
    return PRODUCTS_CACHE.length + ':' + ORDERS_CACHE.length + ':' + REQUESTS_CACHE.length + ':' +
           (PRODUCTS_CACHE[0] ? String(PRODUCTS_CACHE[0].id) + PRODUCTS_CACHE[0].updatedHint : '');
}


/* ⭐ Normalize simu za TZ — ondoa kosa la 'missing country code' kwenye WhatsApp */
function normalizeTZ(num) {
    if (num === null || num === undefined) return num;
    let digits = String(num).replace(/[^\d]/g, '');
    if (!digits) return num;
    if (digits.indexOf('00') === 0) digits = digits.slice(2);
    if (digits.charAt(0) === '0') digits = '255' + digits.slice(1);
    else if (digits.length === 9) digits = '255' + digits;
    return digits;
}
window.waUrl = function (phone, text) {
    const n = normalizeTZ(phone) || '';
    return 'https://wa.me/' + n + (text ? '?text=' + encodeURIComponent(text) : '');
};

function hideLoadingScreen() {
    const loading = document.getElementById('sokoLoading');
    if (loading) {
        loading.style.opacity = '0';
        setTimeout(() => loading.remove(), 400);
    }
}

/* ══════════════════════════════════════════════
   ⭐ 3. LOAD SUPABASE SDK
   ══════════════════════════════════════════════ */
(function loadSupabaseSDK() {
    if (window.supabase && window.supabase.createClient) {
        initSupabaseClient();
        return;
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
    script.onload = initSupabaseClient;
    script.onerror = function () {
        window.dispatchEvent(new Event('sokoDataError'));
        INIT_RESOLVE();
    };
    document.head.appendChild(script);
})();

/* ══════════════════════════════════════════════
   ⭐ 4. INIT CLIENT
   ══════════════════════════════════════════════ */
function initSupabaseClient() {
    try {
        window.supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        initSokoData();
    } catch (e) {
        console.error('❌ Supabase init failed:', e);
        INIT_RESOLVE();
    }
}

/* ══════════════════════════════════════════════
   ⭐ 5. LOAD DATA — stale-while-revalidate
   ══════════════════════════════════════════════ */
async function initSokoData() {
    /* Ficha loading baada ya sekunde 8 hata kama mtandaono */
    setTimeout(hideLoadingScreen, 8000);

    const sb = window.supabaseClient;
    if (!sb) { INIT_RESOLVE(); return; }

    /* ── HATUA 1: Render papo hapo kutoka session cache ── */
    const snap = readSnapshot();
    const cachedUsers = readUsersCache();
    if (cachedUsers && !snap) USERS_CACHE = cachedUsers;   /* ⭐ login instant kutoka cache */
    if (snap) {
        PRODUCTS_CACHE = snap.products || [];
        ORDERS_CACHE = snap.orders || [];
        REQUESTS_CACHE = snap.requests || [];
        if (cachedUsers) USERS_CACHE = cachedUsers;
        DATA_READY = true;
        hideLoadingScreen();
        console.log('⚡ Snapshot:', PRODUCTS_CACHE.length, 'bidhaa |', ORDERS_CACHE.length, 'oda');
        INIT_RESOLVE();
        window.dispatchEvent(new Event('sokoDataReady'));
        autoRenderAll();
    }

    /* ── HATUA 2: Boresha — BIDHAA KWANZA (page ionekane mara moja) ── */
    try {
        /* ⭐ BIDHAA + USERS kwa pamoja — page na login huonekana mara moja */
        const needUsers = !cachedUsers || !cachedUsers.length;
        const [prodsRes, usersRes0] = await Promise.all([
            sb.from('sokoProducts').select('*').order('created_at', { ascending: false }),
            needUsers ? sb.from('sokoUsers').select('*') : Promise.resolve({ data: null })
        ]);
        if (prodsRes.error) console.error('❌ Products:', prodsRes.error.message);
        if (needUsers && usersRes0.data) {
            USERS_CACHE = usersRes0.data.map(u => ({
                id: u.id, name: u.name, email: u.email, password: u.password, role: u.role,
                storeName: u.store_name, phone: normalizeTZ(u.phone), whatsapp: normalizeTZ(u.whatsapp),
                location: u.location, avatar: u.avatar, createdAt: u.created_at
            }));
            writeUsersCache();
        }
        PRODUCTS_CACHE = (prodsRes.data || []).map(p => ({
            id: p.id, name: p.name, category: p.category, condition: p.condition,
            price: p.price, priceVal: p.price_val, stock: p.stock, sales: p.sales,
            description: p.description, images: p.images || [],
            seller: p.seller, sellerEmail: p.seller_email, sellerPhone: normalizeTZ(p.seller_phone),
            sellerWhatsapp: normalizeTZ(p.seller_whatsapp), sellerLocation: p.seller_location,
            sellerAvatar: p.seller_avatar, createdAt: p.created_at
        }));

        /* Products zimefika — washa page kama bado haijaonyeshwa */
        if (!DATA_READY) {
            DATA_READY = true;
            hideLoadingScreen();
            INIT_RESOLVE();
            window.dispatchEvent(new Event('sokoDataReady'));
            autoRenderAll();
        } else {
            window.dispatchEvent(new Event('sokoProductsUpdated'));
        }

        /* ── HATUA 3: Orders + Requests kwa pamoja (nyuma) ── */
        const [ordersRes, requestsRes] = await Promise.all([
            sb.from('sokoOrders').select('*').order('created_at', { ascending: false }),
            sb.from('sokoRequests').select('*').order('created_at', { ascending: false })
        ]);
        if (ordersRes.error) console.error('❌ Orders:', ordersRes.error.message);
        if (requestsRes.error) console.error('❌ Requests:', requestsRes.error.message);

        ORDERS_CACHE = (ordersRes.data || []).map(o => ({
            id: o.id, productId: (o.product_id !== null && o.product_id !== '' && !isNaN(Number(o.product_id))) ? Number(o.product_id) : o.product_id,
            productName: o.product_name, price: o.price, quantity: o.quantity,
            buyerEmail: o.buyer_email, buyerName: o.buyer_name, buyerPhone: normalizeTZ(o.buyer_phone),
            buyerLocation: o.buyer_location, buyerAvatar: o.buyer_avatar, isGuest: o.is_guest,
            seller: o.seller, sellerEmail: o.seller_email, sellerPhone: normalizeTZ(o.seller_phone),
            sellerWhatsapp: normalizeTZ(o.seller_whatsapp), status: o.status, date: o.date,
            dateISO: o.date_iso, createdAt: o.created_at
        }));
        REQUESTS_CACHE = (requestsRes.data || []).map(r => ({
            id: r.id, name: r.name, category: r.category, condition: r.condition,
            quantity: r.quantity, budget: r.budget, phone: normalizeTZ(r.phone), whatsapp: normalizeTZ(r.whatsapp),
            location: r.location, buyer: r.buyer, buyerName: r.buyer_name,
            buyerEmail: r.buyer_email, buyerAvatar: r.buyer_avatar, isGuest: r.is_guest,
            status: r.status, description: r.description, date: r.date, createdAt: r.created_at
        }));

        /* ⭐ OMBI HUISHA baada ya saa 48 — futa zilizopita kiotomatiki */
        const _now = Date.now();
        REQUESTS_CACHE.filter(function (r) {
            return r.createdAt && (_now - new Date(r.createdAt).getTime()) > 48 * 3600 * 1000;
        }).forEach(function (r) {
            console.log('🗑 Ombi limeisha (48h):', r.name);
            SokoDB.deleteRequest(r.id).catch(function () {});
        });

        writeSnapshot();

        /* Refresh UI silently kama data ilibadilika */
        if (snap) {
            window.dispatchEvent(new Event('sokoDataReady'));   /* re-render tables */
        } else {
            window.dispatchEvent(new Event('sokoDataReady'));
            autoRenderAll();
        }
        console.log('✅ Fresh:', { p: PRODUCTS_CACHE.length, o: ORDERS_CACHE.length, r: REQUESTS_CACHE.length, u: USERS_CACHE.length });

    } catch (e) {
        console.error('❌ Load failed:', e);
        if (!DATA_READY) { INIT_RESOLVE(); window.dispatchEvent(new Event('sokoDataError')); }
    }
}

/* ══════════════════════════════════════════════
   ⭐ 6. AUTO-RENDER
   ══════════════════════════════════════════════ */
function autoRenderAll() {
    const fns = [
        'updateHeaderAvatarUI', 'loadDashboardStats', 'renderFeed', 'loadMarketplace',
        'loadProductsTable', 'loadIncomingOrdersTable', 'loadMyOrdersTable',
        'loadBuyerRequestsUI', 'loadMyDemands', 'renderMediaPicker'
    ];
    fns.forEach(fn => {
        if (typeof window[fn] === 'function') {
            try { window[fn](); } catch (e) { console.warn('  ⚠️ ' + fn + ':', e.message); }
        }
    });
}

/* ══════════════════════════════════════════════
   ⭐ 7. SokoDB — API (IMEBAKI SAWA)
   ══════════════════════════════════════════════ */
const SokoDB = {
    getUsers: () => USERS_CACHE,

    registerUser: async function (userData) {
        try {
            const sb = window.supabaseClient;
            const { data: existing } = await sb.from('sokoUsers').select('email')
                .eq('email', userData.email).maybeSingle();
            if (existing) return { success: false, message: "Barua pepe hii imeshajisajiliwa tayari!" };

            const insertData = {
                name: userData.name, email: userData.email, password: userData.password,
                role: userData.role, store_name: userData.storeName || null,
                phone: userData.phone || null, whatsapp: userData.whatsapp || userData.phone || null,
                location: userData.location || null, avatar: userData.avatar || null
            };
            const { data, error } = await sb.from('sokoUsers').insert([insertData]).select().single();
            if (error) return { success: false, message: error.message };

            const newUser = {
                id: data.id, name: data.name, email: data.email, password: data.password,
                role: data.role, storeName: data.store_name, phone: data.phone,
                whatsapp: data.whatsapp, location: data.location, avatar: data.avatar,
                createdAt: data.created_at
            };
            USERS_CACHE.push(newUser);
            writeUsersCache();
            localStorage.setItem('sokoActiveUser', JSON.stringify(newUser));
            return { success: true, role: newUser.role };
        } catch (e) { return { success: false, message: "Error: " + e.message }; }
    },

    loginUser: function (email, password) {
        const user = USERS_CACHE.find(u => u.email === email && u.password === password);
        if (user) {
            localStorage.setItem('sokoActiveUser', JSON.stringify(user));
            return { success: true, role: user.role };
        }
        return { success: false, message: "Barua pepe au neno la siri si sahihi!" };
    },

    getUser: function () {
        try {
            const u = localStorage.getItem('sokoActiveUser');
            if (!u) return null;
            const parsed = JSON.parse(u);
            if (!parsed || typeof parsed !== 'object' || !parsed.email) {
                localStorage.removeItem('sokoActiveUser');
                return null;
            }
            return parsed;
        } catch (e) {
            localStorage.removeItem('sokoActiveUser');
            return null;
        }
    },

    saveUser: async function (userData) {
        try {
            const sb = window.supabaseClient;
            if (!userData.id) return;
            const updateData = {
                name: userData.name, store_name: userData.storeName,
                phone: userData.phone, whatsapp: userData.whatsapp,
                location: userData.location, avatar: userData.avatar
            };
            const { error } = await sb.from('sokoUsers').update(updateData).eq('id', userData.id);
            if (error) throw error;
            const idx = USERS_CACHE.findIndex(u => String(u.id) === String(userData.id));
            if (idx !== -1) USERS_CACHE[idx] = userData; else USERS_CACHE.push(userData);
            writeUsersCache();
            localStorage.setItem('sokoActiveUser', JSON.stringify(userData));
        } catch (e) { throw e; }
    },

    logout: function () {
        localStorage.removeItem('sokoActiveUser');
        /* Usifute snapshot — page zijazo zitafungua haraka */
    },

    getProducts: () => PRODUCTS_CACHE,

    saveProduct: async function (p) {
        try {
            const sb = window.supabaseClient;
            const insertData = {
                name: p.name, category: p.category, condition: p.condition,
                price: p.price, price_val: p.priceVal || 0, stock: p.stock || 0, sales: 0,
                description: p.description, images: p.images || [],
                seller: p.seller, seller_email: p.sellerEmail, seller_phone: p.sellerPhone,
                seller_whatsapp: p.sellerWhatsapp, seller_location: p.sellerLocation,
                seller_avatar: p.sellerAvatar
            };
            const { data, error } = await sb.from('sokoProducts').insert([insertData]).select().single();
            if (error) throw error;
            const newP = {
                id: data.id, name: data.name, category: data.category, condition: data.condition,
                price: data.price, priceVal: data.price_val, stock: data.stock, sales: data.sales,
                description: data.description, images: data.images || [],
                seller: data.seller, sellerEmail: data.seller_email, sellerPhone: data.seller_phone,
                sellerWhatsapp: data.seller_whatsapp, sellerLocation: data.seller_location,
                sellerAvatar: data.seller_avatar, createdAt: data.created_at
            };
            PRODUCTS_CACHE.unshift(newP);
            writeSnapshot();
            return newP;
        } catch (e) { throw e; }
    },

    updateProduct: async function (p) {
        try {
            const sb = window.supabaseClient;
            if (!p.id) throw new Error('Product ID haipo');
            const updateData = {
                name: p.name, category: p.category, condition: p.condition,
                price: p.price, stock: p.stock, sales: p.sales || 0,
                description: p.description, images: p.images || []
            };
            const { error } = await sb.from('sokoProducts').update(updateData).eq('id', p.id);
            if (error) throw error;
            const idx = PRODUCTS_CACHE.findIndex(x => String(x.id) === String(p.id));
            if (idx !== -1) PRODUCTS_CACHE[idx] = p;
            writeSnapshot();
            return p;
        } catch (e) { throw e; }
    },

    deleteProduct: async function (id) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('Product ID haipo');
            const { error } = await sb.from('sokoProducts').delete().eq('id', id);
            if (error) throw error;
            PRODUCTS_CACHE = PRODUCTS_CACHE.filter(p => String(p.id) !== String(id));
            writeSnapshot();
        } catch (e) { throw e; }
    },

    getOrders: () => ORDERS_CACHE,

    saveOrder: async function (o) {
        try {
            const sb = window.supabaseClient;
            const insertData = {
                product_id: String(o.productId || ''), product_name: o.productName,
                price: o.price, quantity: o.quantity || 1,
                buyer_email: o.buyerEmail, buyer_name: o.buyerName, buyer_phone: o.buyerPhone,
                buyer_location: o.buyerLocation, buyer_avatar: o.buyerAvatar || '',
                is_guest: o.isGuest || false, seller: o.seller, seller_email: o.sellerEmail,
                seller_phone: o.sellerPhone, seller_whatsapp: o.sellerWhatsapp,
                status: o.status || 'Imewekwa (Pending)', date: o.date,
                date_iso: new Date().toISOString()
            };
            const { data, error } = await sb.from('sokoOrders').insert([insertData]).select().single();
            if (error) throw error;
            const newO = {
                id: data.id, productId: (data.product_id !== null && data.product_id !== '' && !isNaN(Number(data.product_id))) ? Number(data.product_id) : data.product_id,
                productName: data.product_name, price: data.price, quantity: data.quantity,
                buyerEmail: data.buyer_email, buyerName: data.buyer_name, buyerPhone: data.buyer_phone,
                buyerLocation: data.buyer_location, buyerAvatar: data.buyer_avatar, isGuest: data.is_guest,
                seller: data.seller, sellerEmail: data.seller_email, sellerPhone: data.seller_phone,
                sellerWhatsapp: data.seller_whatsapp, status: data.status, date: data.date,
                dateISO: data.date_iso, createdAt: data.created_at
            };
            ORDERS_CACHE.unshift(newO);
            writeSnapshot();
            return newO;
        } catch (e) { throw e; }
    },

    updateOrder: async function (o) {
        try {
            const sb = window.supabaseClient;
            if (!o.id) throw new Error('Order ID haipo');
            const { error } = await sb.from('sokoOrders')
                .update({ quantity: o.quantity, status: o.status }).eq('id', o.id);
            if (error) throw error;
            const idx = ORDERS_CACHE.findIndex(x => String(x.id) === String(o.id));
            if (idx !== -1) ORDERS_CACHE[idx] = o;
            writeSnapshot();
            return o;
        } catch (e) { throw e; }
    },

    updateOrderStatus: async function (id, status) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('Order ID haipo');
            const { error } = await sb.from('sokoOrders').update({ status: status }).eq('id', id);
            if (error) throw error;
            const idx = ORDERS_CACHE.findIndex(o => String(o.id) === String(id));
            if (idx !== -1) ORDERS_CACHE[idx].status = status;
            writeSnapshot();
        } catch (e) { throw e; }
    },

    deleteOrder: async function (id) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('Order ID haipo');
            const { error } = await sb.from('sokoOrders').delete().eq('id', id);
            if (error) throw error;
            ORDERS_CACHE = ORDERS_CACHE.filter(o => String(o.id) !== String(id));
            writeSnapshot();
        } catch (e) { throw e; }
    },

    getRequests: () => REQUESTS_CACHE,

    saveRequest: async function (r) {
        try {
            const sb = window.supabaseClient;
            const insertData = {
                name: r.name, category: r.category || 'Ombi', condition: r.condition || 'Mpya',
                quantity: r.quantity || 1, budget: r.budget, phone: r.phone, whatsapp: r.whatsapp,
                location: r.location, buyer: r.buyer, buyer_name: r.buyerName || r.buyer,
                buyer_email: r.buyerEmail, buyer_avatar: r.buyerAvatar || '',
                is_guest: r.isGuest || false, status: r.status || 'Open',
                description: r.description || '', date: r.date
            };
            const { data, error } = await sb.from('sokoRequests').insert([insertData]).select().single();
            if (error) throw error;
            const newR = {
                id: data.id, name: data.name, category: data.category, condition: data.condition,
                quantity: data.quantity, budget: data.budget, phone: data.phone, whatsapp: data.whatsapp,
                location: data.location, buyer: data.buyer, buyerName: data.buyer_name,
                buyerEmail: data.buyer_email, buyerAvatar: data.buyer_avatar, isGuest: data.is_guest,
                status: data.status, description: data.description, date: data.date, createdAt: data.created_at
            };
            REQUESTS_CACHE.unshift(newR);
            writeSnapshot();
            return newR;
        } catch (e) { throw e; }
    },

    deleteRequest: async function (id) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('Request ID haipo');
            const { error } = await sb.from('sokoRequests').delete().eq('id', id);
            if (error) throw error;
            REQUESTS_CACHE = REQUESTS_CACHE.filter(r => String(r.id) !== String(id));
            writeSnapshot();
        } catch (e) { throw e; }
    },

    updateRequestStatus: async function (id, status) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('Request ID haipo');
            const { error } = await sb.from('sokoRequests').update({ status: status }).eq('id', id);
            if (error) throw error;
            const idx = REQUESTS_CACHE.findIndex(r => String(r.id) === String(id));
            if (idx !== -1) REQUESTS_CACHE[idx].status = status;
            writeSnapshot();
        } catch (e) { throw e; }
    },

    deleteUser: async function (id) {
        try {
            const sb = window.supabaseClient;
            if (!id) throw new Error('User ID haipo');
            const { error } = await sb.from('sokoUsers').delete().eq('id', id);
            if (error) throw error;
            USERS_CACHE = USERS_CACHE.filter(u => String(u.id) !== String(id));
            writeUsersCache();
        } catch (e) { throw e; }
    },

    isReady: () => DATA_READY,
    refresh: () => initSokoData()
};

window.SokoDB = SokoDB;
window.initSokoData = initSokoData;
window.autoRenderAll = autoRenderAll;

/* ══════════════════════════════════════════════
   ⭐ 8. PICHA — Storage + compression (BANDWIDTH FIX)
   ══════════════════════════════════════════════ */
function compressImage(file, maxDim, quality) {
    maxDim = maxDim || 1280;
    quality = quality || 0.82;
    return new Promise(function (resolve, reject) {
        const img = new Image();
        const url = URL.createObjectURL(file);
        img.onload = function () {
            let w = img.width, h = img.height;
            if (w > maxDim || h > maxDim) {
                const ratio = Math.min(maxDim / w, maxDim / h);
                w = Math.round(w * ratio);
                h = Math.round(h * ratio);
            }
            const canvas = document.createElement('canvas');
            canvas.width = w; canvas.height = h;
            canvas.getContext('2d').drawImage(img, 0, 0, w, h);
            URL.revokeObjectURL(url);
            canvas.toBlob(function (blob) {
                if (blob) resolve(blob); else reject(new Error('Compression imeshindwa'));
            }, 'image/jpeg', quality);
        };
        img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('Picha si sahihi')); };
        img.src = url;
    });
}

async function uploadToStorage(file, folder, maxDim) {
    const sb = window.supabaseClient;
    /* ⭐ Jaribu compression; kama ishindwe (picha kubwa mno / format), tuma faili kama lilivyo */
    let blob, contentType;
    try {
        blob = await compressImage(file, maxDim || 1280, 0.82);
        contentType = 'image/jpeg';
    } catch (e) {
        console.warn('⚠️ Compression imeshindwa — inatuma faili original:', e.message);
        blob = file;
        contentType = file.type || 'image/jpeg';
    }
    const path = folder + '/' + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '_' + Math.random().toString(36).slice(2)) + (contentType === 'image/jpeg' ? '.jpg' : '');
    const { error } = await sb.storage.from('soko-images').upload(path, blob, { contentType: contentType, upsert: false });
    if (error) throw error;
    const { data } = sb.storage.from('soko-images').getPublicUrl(path);
    return data.publicUrl;
}

async function uploadProductImage(file) {
    return uploadToStorage(file, 'products', 1280);
}
async function uploadAvatarImage(file) {
    return uploadToStorage(file, 'avatars', 400);
}
window.uploadProductImage = uploadProductImage;
window.uploadAvatarImage = uploadAvatarImage;

console.log('📦 data.js loaded (optimized)');
})();
