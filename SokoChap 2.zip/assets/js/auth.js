/**
 * ============================================================================
 * SOKO LAKO - CENTRALIZED AUTH & ROUTER HELPER (auth.js)
 * Description: Manages user login, registration, session persistence, and redirects.
 * ============================================================================
 */

'use strict';

// 1. INAYOSIMAMIA KUINGIA (LOGIN)
function processUserLogin(event) {
    event.preventDefault();
    const role = document.getElementById('loginRole').value;
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;

    let users = JSON.parse(localStorage.getItem('sokoRegisteredUsers')) || [];
    let foundUser = users.find(u => u.email === email && u.role === role && u.password === password);

    // Kama haipo kwenye registered list, tengeneza akaunti ya haraka (Fallback for testing)
    if (!foundUser) {
        foundUser = {
            name: email.split('@')[0],
            email: email,
            role: role,
            storeName: role === 'seller' ? 'Duka la ' + email.split('@')[0] : null,
            phone: "+255 700 000 000"
        };
    }

    // Hifadhi active session
    localStorage.setItem('sokoActiveUser', JSON.stringify(foundUser));

    // Elekeza moja kwa moja kulingana na Role yake
    redirectToDashboard(foundUser.role);
}

// 2. INAYOSIMAMIA KUJISAJILI (REGISTER)
function processUserRegister(event) {
    event.preventDefault();
    const name = document.getElementById('regName').value.trim();
    const role = document.getElementById('regRole').value;
    const email = document.getElementById('regEmail').value.trim().toLowerCase();
    const phone = document.getElementById('regPhone').value.trim();
    const password = document.getElementById('regPassword').value;

    let users = JSON.parse(localStorage.getItem('sokoRegisteredUsers')) || [];

    const newUser = {
        name: name,
        email: email,
        phone: phone,
        role: role,
        password: password,
        storeName: role === 'seller' ? 'Duka la ' + name : null
    };

    users.push(newUser);
    localStorage.setItem('sokoRegisteredUsers', JSON.stringify(users));
    localStorage.setItem('sokoActiveUser', JSON.stringify(newUser));

    alert('Akaunti imefunguliwa na umeingia kwenye mfumo!');
    redirectToDashboard(role);
}

// 3. INAYOSIMAMIA UELEKEZAJI (REDIRECT MANAGER)
function redirectToDashboard(role) {
    if (role === 'seller') {
        window.location.href = 'seller-dashboard.html';
    } else {
        window.location.href = 'buyer-dashboard.html';
    }
}

// 4. ULINZI WA KURASA (ROUTE GUARD - Inazuia mtu kuingia sehemu isiyomhusu)
function enforceRouteGuard(requiredRole) {
    const activeUser = JSON.parse(localStorage.getItem('sokoActiveUser'));
    
    if (!activeUser) {
        alert('Tafadhali ingia kwenye akaunti kwanza.');
        window.location.href = 'login.html';
        return;
    }

    if (activeUser.role !== requiredRole) {
        alert('Hauruhusiwi kufikia ukurasa huu.');
        redirectToDashboard(activeUser.role);
    }
}

// 5. KUTOKA KWENYE MFUMO (LOGOUT)
function logoutUserSession() {
    localStorage.removeItem('sokoActiveUser');
    window.location.href = 'index.html';
}
