/* ============================================================
   SOKOCHAP — GUEST APP (Clean Version)
   ============================================================ */

const $ = id => document.getElementById(id);

function escapeHTML(str) {
    var s = String(str ?? "");
    return s
        .split("&").join("&amp;")
        .split("<").join("&lt;")
        .split(">").join("&gt;")
        .split('"').join("&quot;")
        .split("'").join("&#39;");
}

const cleanPhone = num => String(num || "").replace(/[^\d]/g, "");

const initials = name => (name || "?").split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();

const fmtDate = d => {
    try {
        return new Date(d).toLocaleDateString('sw-TZ', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    } catch (e) {
        return '—';
    }
};

let CURRENT_PRODUCT = null;

/* ============================================================
   TOAST
   ============================================================ */

function showToast(message, type) {
    type = type || 'success';
    const container = $('toast-container');
    if (!container) {
        alert(message); // Fallback kama container haipo
        return;
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast ' + type;
    
    const icon = type === 'success' ?
        '<i class="fa-solid fa-circle-check" style="color: #16a34a; font-size: 18px;"></i>' :
        type === 'error' ?
        '<i class="fa-solid fa-circle-exclamation" style="color: #dc2626; font-size: 18px;"></i>' :
        '<i class="fa-solid fa-circle-info" style="color: #0ea5e9; font-size: 18px;"></i>';
    
    toast.innerHTML = '<div style="display:flex;align-items:center;gap:10px;">' +
        icon +
        '<span style="font-size:13px;font-weight:600;color:#0f172a;">' + escapeHTML(message) + '</span>' +
        '</div>';
    
    // Style
    toast.style.cssText =
        'background: white; ' +
        'padding: 14px 18px; ' +
        'border-radius: 12px; ' +
        'box-shadow: 0 15px 30px -5px rgba(0,0,0,0.15); ' +
        'border-left: 4px solid ' + (type === 'success' ? '#16a34a' : type === 'error' ? '#dc2626' : '#0ea5e9') + '; ' +
        'margin-bottom: 10px; ' +
        'animation: toastSlideIn 0.3s ease forwards; ' +
        'opacity: 0; ' +
        'transform: translateX(50px); ' +
        'pointer-events: auto;';
    
    container.appendChild(toast);
    
    // Animate in
    requestAnimationFrame(function() {
        toast.style.transition = 'all 0.3s ease';
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
    });
    
    // Auto remove
    setTimeout(function() {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(50px)';
        setTimeout(function() { toast.remove(); }, 300);
    }, 3500);
}



/* ============================================================
   RENDER FEED
   ============================================================ */
function renderFeed(list) {
    const feed = $("productFeed");
    if (!feed) return;
    
    feed.innerHTML = "";
    
    const products = list || SokoDB.getProducts();
    
    if (!products.length) {
        feed.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#94a3b8;">' +
            '<i class="fa-solid fa-box-open" style="font-size:48px;color:#cbd5e1;margin-bottom:12px;display:block;"></i>' +
            '<p style="font-size:13px;font-weight:600;">Hakuna bidhaa iliyopo kwa sasa.</p>' +
            '</div>';
        return;
    }
    
    products.forEach(function(p, i) {
        const firstImg = (p.images && p.images[0]) || p.image || "";
        const imgCount = (p.images && p.images.length) || 0;
        
        const card = document.createElement("div");
        card.className = "product-card";
        card.style.transitionDelay = ((i % 10) * 0.05) + "s";
        
        // ⭐ Build HTML kwa concatenation — hakuna backtick inayogongana
        let imgHTML;
        if (firstImg) {
            imgHTML = '<img loading="lazy" decoding="async" src="' + escapeHTML(firstImg) + '" alt="' + escapeHTML(p.name) + '" ' +
                'onerror="this.style.display=\'none\';this.parentElement.innerHTML=\'<div style=&quot;display:flex;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:11px;&quot;>[Picha]</div>\';">';
        } else {
            imgHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:11px;">[Picha]</div>';
        }
        
        const imgCountHTML = imgCount > 1
            ? '<span class="img-count"><i class="fa-solid fa-images"></i> ' + imgCount + '</span>'
            : '';
        
        const sellerInitial = initials(p.seller);
        const avatarHTML = p.sellerAvatar
            ? '<img src="' + escapeHTML(p.sellerAvatar) + '" alt="">'
            : '<i class="fa-solid fa-user" style="font-size:11px;"></i>';
        
        // ⭐ Tumia data-attributes badala ya onclick inline
        // ⭐ Check kama imeisha
var isSoldOut = (parseInt(p.stock) || 0) <= 0;

// ⭐ Badge ya "Imeisha" kwenye picha
var soldOutBadge = isSoldOut ?
    '<span style="position: absolute; top: 10px; right: 10px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 5px 12px; border-radius: 20px; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); display: inline-flex; align-items: center; gap: 4px; z-index: 2;">' +
    '<i class="fa-solid fa-fire"></i> Imeisha' +
    '</span>' :
    '';

card.innerHTML =
    '<div class="product-img" data-action="view-product" data-id="' + p.id + '" style="position: relative;">' +
    imgHTML +
    imgCountHTML +
    soldOutBadge +
    '</div>' +
    '<div class="product-body">' +
    '<span class="product-cat">' + escapeHTML(p.category || "Bidhaa") + '</span>' +
    '<div class="product-title" data-action="view-product" data-id="' + p.id + '">' + escapeHTML(p.name) + '</div>' +
    '<div class="product-price">' + escapeHTML(p.price) + '</div>' +
    '<div class="product-loc">' +
    '<i class="fa-solid fa-location-dot"></i> ' +
    escapeHTML(p.sellerLocation || "Tanzania") +
    '</div>' +
    '<div class="seller-row">' +
    '<div class="seller-info">' +
    '<div class="seller-avatar">' + avatarHTML + '</div>' +
    '<span class="seller-name">' + escapeHTML(p.seller || "Muuzaji") + '</span>' +
    '</div>' +
    '<button class="btn-profile" data-action="view-seller" data-id="' + p.id + '">' +
    '<i class="fa-solid fa-store"></i> Wasifu' +
    '</button>' +
    '</div>' +
    (isSoldOut ?
        '<button class="btn-order-mini" disabled style="background: #f1f5f9; color: #94a3b8; border-color: #e2e8f0; cursor: not-allowed;">' +
        '<i class="fa-solid fa-ban"></i> Imeisha' +
        '</button>' :
        '<button class="btn-order-mini" data-action="order-product" data-id="' + p.id + '">' +
        '<i class="fa-solid fa-cart-plus"></i> Weka Oda' +
        '</button>'
    ) +
    '</div>';
        
        feed.appendChild(card);
        
        setTimeout(function() {
            card.classList.add('visible');
        }, 50 + (i * 30));
    });
}

/* ============================================================
   EVENT DELEGATION — Badala ya onclick inline
   ============================================================ */
let _clickLock = false;

document.addEventListener('click', function(e) {
    const target = e.target.closest('[data-action]');
    if (!target) return;
    
    const action = target.dataset.action;
    const id = target.dataset.id;
    
    if (action === 'view-product') {
        e.stopPropagation();
        openProductTab(id);
    } else if (action === 'view-seller') {
        e.stopPropagation();
        openSellerTabByProduct(id);
    } else if (action === 'order-product') {
        e.stopPropagation();
        
        // ⭐ Zuia double-click
        if (_clickLock) return;
        _clickLock = true;
        setTimeout(() => { _clickLock = false; }, 500);
        
        openOrderModal(id);
    }
});
/* ============================================================
   PRODUCT TAB
   ============================================================ */

function openProductTab(productId) {
    const p = SokoDB.getProducts().find(function(x) { return x.id === productId; });
    if (!p) return;
    
    CURRENT_PRODUCT = p;
    const images = (p.images && p.images.length) ? p.images : [p.image || ""];
    
    // ⭐ ONGEZA HII — Check kama imeisha
    const isSoldOut = (parseInt(p.stock) || 0) <= 0;
    
    let mainImgHTML;
    if (images[0]) {
        mainImgHTML = '<img id="detailMainImg" src="' + escapeHTML(images[0]) + '" alt="' + escapeHTML(p.name) + '">';
    } else {
        mainImgHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:13px;">[Picha]</div>';
    }
    
    let thumbsHTML = '';
    if (images.length > 1) {
        thumbsHTML = '<div class="detail-thumbs">';
        images.forEach(function(img, i) {
            thumbsHTML += '<div class="detail-thumb ' + (i === 0 ? 'active' : '') + '" data-action="switch-img" data-src="' + escapeHTML(img) + '">' +
                '<img src="' + escapeHTML(img) + '" alt="">' +
                '</div>';
        });
        thumbsHTML += '</div>';
    }
    
    const sellerAvatarHTML = p.sellerAvatar ?
        '<img src="' + escapeHTML(p.sellerAvatar) + '" alt="">' :
        '<i class="fa-solid fa-user"></i>';
    
    const locHTML = p.sellerLocation ?
        '<span class="chip"><i class="fa-solid fa-location-dot"></i> ' + escapeHTML(p.sellerLocation) + '</span>' :
        '';
    
    $("productTabContent").innerHTML =
        '<div class="detail-hero-img" style="position:relative;">' +
        mainImgHTML +
        // ⭐ Badge kama imeisha
        (isSoldOut ?
            '<span style="position:absolute; top:12px; right:12px; background:linear-gradient(135deg,#ef4444,#dc2626); color:white; padding:6px 14px; border-radius:20px; font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:0.5px; box-shadow:0 4px 12px rgba(239,68,68,0.4); display:inline-flex; align-items:center; gap:5px; z-index:2;">' +
            '<i class="fa-solid fa-fire"></i> Imeisha' +
            '</span>' :
            ''
        ) +
        '</div>' +
        thumbsHTML +
        '<span class="detail-cat"><i class="fa-solid fa-tag"></i> ' + escapeHTML(p.category || "Bidhaa") + '</span>' +
        '<h1 class="detail-name">' + escapeHTML(p.name) + '</h1>' +
        '<div class="detail-price">' + escapeHTML(p.price) + '</div>' +
        '<div class="detail-chips">' +
        '<span class="chip"><i class="fa-solid fa-star"></i> ' + escapeHTML(p.condition || "Mpya") + '</span>' +
        (isSoldOut ?
            '<span class="chip" style="background:#fee2e2; border-color:#fecaca; color:#991b1b;"><i class="fa-solid fa-ban"></i> Imeisha</span>' :
            '<span class="chip"><i class="fa-solid fa-box"></i> Stock ' + (p.stock || 0) + '</span>'
        ) +
        locHTML +
        '</div>' +
        '<div class="detail-desc">' + escapeHTML(p.description || "Hakuna maelezo zaidi.") + '</div>' +
        '<div class="seller-block" data-action="view-seller" data-id="' + p.id + '">' +
        '<div class="seller-block-avatar">' + sellerAvatarHTML + '</div>' +
        '<div class="seller-block-info">' +
        '<div class="seller-block-label">Muuzaji</div>' +
        '<div class="seller-block-name">' +
        escapeHTML(p.seller || "Muuzaji") +
        ' <i class="fa-solid fa-circle-check"></i>' +
        '</div>' +
        '<div class="seller-block-loc">' +
        '<i class="fa-solid fa-location-dot" style="color:#e11d48;font-size:9px;"></i> ' +
        escapeHTML(p.sellerLocation || "Tanzania") +
        '</div>' +
        '</div>' +
        '<i class="fa-solid fa-chevron-right seller-block-chevron"></i>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:10px;">' +
        (isSoldOut ?
            '<button class="btn-primary-action" disabled style="background:#94a3b8; cursor:not-allowed; opacity:0.8;">' +
            '<i class="fa-solid fa-ban"></i> Bidhaa Imeisha' +
            '</button>' :
            '<button class="btn-primary-action" data-action="order-product" data-id="' + p.id + '">' +
            '<i class="fa-solid fa-cart-plus"></i> Weka Oda ya Bidhaa Hii' +
            '</button>'
        ) +
        '<a class="btn-whatsapp-action" href="https://wa.me/' + cleanPhone(p.sellerWhatsapp) + '?text=' + encodeURIComponent('Habari ' + (p.seller || '') + ', nina nia ya kununua ' + p.name) + '" target="_blank" rel="noopener">' +
        '<i class="fa-brands fa-whatsapp"></i> Wasiliana WhatsApp' +
        '</a>' +
        '</div>';
    
    $("productTab").classList.add("active");
    document.body.style.overflow = "hidden";
}


/* ============================================================
   SWITCH IMAGE
   ============================================================ */
document.addEventListener('click', function(e) {
    const thumb = e.target.closest('[data-action="switch-img"]');
    if (!thumb) return;
    
    const src = thumb.dataset.src;
    const mainImg = $("detailMainImg");
    if (mainImg) mainImg.src = src;
    
    document.querySelectorAll('.detail-thumb').forEach(function(t) { t.classList.remove('active'); });
    thumb.classList.add('active');
});

/* ============================================================
   CLOSE TAB
   ============================================================ */
function closeTab(tabId) {
    const tab = $(tabId);
    if (tab) tab.classList.remove("active");
    document.body.style.overflow = "";
}

/* ============================================================
   OPEN SELLER TAB — kwa Product ID (rahisi na salama)
   ============================================================ */

function openSellerTabByProduct(productId) {
    const p = SokoDB.getProducts().find(function(x) { return x.id === productId; });
    if (!p) return;
    
    const allProds = SokoDB.getProducts();
    const sellerIdentifier = p.sellerEmail || p.seller || p.sellerName;
    
    // ⭐ Filter — rahisi
    const sellerProds = allProds.filter(function(x) {
        var xId = x.sellerEmail || x.seller || x.sellerName;
        return xId === sellerIdentifier;
    });
    
    console.log('=== SELLER TAB ===');
    console.log('Identifier:', sellerIdentifier);
    console.log('Total:', allProds.length);
    console.log('Matched:', sellerProds.length);
    
    // ⭐ Build tab content kwa DOM methods (SAFI KABISA)
    const content = $("sellerTabContent");
    content.innerHTML = ""; // Clear
    
    // ⭐ SELLER HERO
    const hero = document.createElement('div');
    hero.className = 'profile-hero';
    
    const heroBg = document.createElement('div');
    heroBg.className = 'profile-hero-bg';
    hero.appendChild(heroBg);
    
    const heroAvatar = document.createElement('div');
    heroAvatar.className = 'profile-hero-avatar';
    if (p.sellerAvatar) {
        const img = document.createElement('img');
        img.src = p.sellerAvatar;
        img.alt = '';
        heroAvatar.appendChild(img);
    } else {
        const icon = document.createElement('i');
        icon.className = 'fa-solid fa-user';
        heroAvatar.appendChild(icon);
    }
    hero.appendChild(heroAvatar);
    
    const heroName = document.createElement('div');
    heroName.className = 'profile-hero-name';
    heroName.textContent = p.seller || "Muuzaji";
    const check = document.createElement('i');
    check.className = 'fa-solid fa-circle-check';
    heroName.appendChild(document.createTextNode(' '));
    heroName.appendChild(check);
    hero.appendChild(heroName);
    
    const heroMeta = document.createElement('div');
    heroMeta.className = 'profile-hero-meta';
    heroMeta.innerHTML = '<i class="fa-solid fa-location-dot" style="color:#e11d48;"></i> ';
    heroMeta.appendChild(document.createTextNode(p.sellerLocation || "Tanzania"));
    hero.appendChild(heroMeta);
    
    content.appendChild(hero);
    
    // ⭐ STATS
    const stats = document.createElement('div');
    stats.className = 'profile-stats';
    stats.innerHTML =
        '<div class="profile-stat"><div class="profile-stat-value">' + sellerProds.length + '</div><div class="profile-stat-label">Bidhaa</div></div>' +
        '<div class="profile-stat"><div class="profile-stat-value">4.8</div><div class="profile-stat-label">Rating</div></div>' +
        '<div class="profile-stat"><div class="profile-stat-value">0</div><div class="profile-stat-label">Mauzo</div></div>';
    content.appendChild(stats);
    
    // ⭐ ACTIONS
    const actions = document.createElement('div');
    actions.className = 'profile-actions';
    
    const waLink = document.createElement('a');
    waLink.className = 'btn-whatsapp-action';
    waLink.href = 'https://wa.me/' + cleanPhone(p.sellerWhatsapp) + '?text=' + encodeURIComponent('Habari ' + (p.seller || ''));
    waLink.target = '_blank';
    waLink.innerHTML = '<i class="fa-brands fa-whatsapp"></i> WhatsApp';
    actions.appendChild(waLink);
    
    const phoneLink = document.createElement('a');
    phoneLink.className = 'btn-primary-action';
    phoneLink.href = 'tel:' + cleanPhone(p.sellerPhone);
    phoneLink.innerHTML = '<i class="fa-solid fa-phone"></i> Piga Simu';
    actions.appendChild(phoneLink);
    
    content.appendChild(actions);
    
    // ⭐ TITLE
    const title = document.createElement('div');
    title.className = 'profile-products-title';
    title.textContent = 'Bidhaa za ' + (p.seller || "Muuzaji") + ' (' + sellerProds.length + ')';
    content.appendChild(title);
    
    // ⭐ PRODUCTS GRID
    const grid = document.createElement('div');
    grid.className = 'profile-products-grid';
    
    if (sellerProds.length === 0) {
        const empty = document.createElement('div');
        empty.style.cssText = 'grid-column:1/-1;text-align:center;padding:40px 20px;color:#94a3b8;';
        empty.innerHTML = '<i class="fa-solid fa-box-open" style="font-size:36px;color:#cbd5e1;margin-bottom:10px;display:block;"></i><p style="font-size:13px;">Hakuna bidhaa zingine.</p>';
        grid.appendChild(empty);
    } else {
        sellerProds.forEach(function(sp) {
            const card = document.createElement('div');
card.className = 'product-card';
card.style.cssText =
    'opacity: 1 !important; ' +
    'transform: none !important; ' +
    'visibility: visible !important; ' +
    'display: flex; ' +
    'flex-direction: column; ' +
    'background: #fff; ' +
    'border: 1px solid #e2e8f0; ' +
    'border-radius: 14px; ' +
    'overflow: hidden; ' +
    'cursor: pointer;';
            
            // Click — fungua product
            
            
            // Image
            const imgWrap = document.createElement('div');
            imgWrap.className = 'product-img';
            
            var imgSrc = (sp.images && sp.images[0]) || sp.image || "";
            if (imgSrc) {
                const img = document.createElement('img');
                img.src = imgSrc;
                img.alt = sp.name || '';
                img.onerror = function() {
                    this.style.display = 'none';
                    this.parentElement.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:11px;">[Picha]</div>';
                };
                imgWrap.appendChild(img);
            } else {
                imgWrap.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:11px;">[Picha]</div>';
            }
            card.appendChild(imgWrap);
            
            // Body
            const body = document.createElement('div');
            body.className = 'product-body';
            
            var cat = document.createElement('span');
            cat.className = 'product-cat';
            cat.textContent = sp.category || "Bidhaa";
            body.appendChild(cat);
            
            var title = document.createElement('div');
            title.className = 'product-title';
            title.style.cssText = 'font-size:12px;min-height:auto;';
            title.textContent = sp.name || "Bidhaa";
            body.appendChild(title);
            
            var price = document.createElement('div');
            price.className = 'product-price';
            price.style.fontSize = '14px';
            price.textContent = sp.price || "—";
            body.appendChild(price);
            
            // Order button
            var orderBtn = document.createElement('button');
            orderBtn.className = 'btn-order-mini';
            orderBtn.setAttribute('data-action', 'order-product');
            orderBtn.setAttribute('data-id', sp.id);
            orderBtn.innerHTML = '<i class="fa-solid fa-cart-plus"></i> Weka Oda';
            body.appendChild(orderBtn);
            
            card.appendChild(body);
            grid.appendChild(card);
        });
    }
    
    content.appendChild(grid);
    
    // ⭐ Onyesha tab
    $("sellerTab").classList.add("active");
    document.body.style.overflow = "hidden";
}

/* ============================================================
   ORDER MODAL
   ============================================================ */
function openOrderModal(productId) {
    const p = SokoDB.getProducts().find(function(x) { return x.id === productId; });
    if (!p) return;
    
    CURRENT_PRODUCT = p;
    
    const img = (p.images && p.images[0]) || p.image || "";
    const imgHTML = img ?
        '<img src="' + escapeHTML(img) + '" style="width:50px;height:50px;object-fit:cover;border-radius:10px;flex-shrink:0;" onerror="this.style.display=\'none\';">' :
        '';
    
    $("modalPanel").innerHTML =
        '<div class="modal-handle"></div>' +
        '<div class="modal-header">' +
        '<span class="modal-title"><i class="fa-solid fa-cart-plus" style="color:#0ea5e9;"></i> Weka Oda</span>' +
        '<button type="button" class="modal-close" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:10px;padding:10px;background:#f8fafc;border-radius:12px;margin-bottom:18px;border:1px solid #e2e8f0;">' +
        imgHTML +
        '<div style="flex:1;min-width:0;">' +
        '<div style="font-size:13px;font-weight:800;color:#0f172a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + escapeHTML(p.name) + '</div>' +
        '<div style="font-size:14px;font-weight:800;color:#10b981;margin-top:2px;">' + escapeHTML(p.price) + '</div>' +
        '</div>' +
        '</div>' +
        '<form id="orderForm">' +
        '<div class="form-group">' +
        '<label class="form-label"><i class="fa-solid fa-user"></i> Jina Lako Kamili</label>' +
        '<input type="text" name="buyerName" class="form-input" placeholder="Mfano: Juma Ali" required>' +
        '</div>' +
        '<div class="form-group">' +
        '<label class="form-label"><i class="fa-solid fa-phone"></i> Namba ya Simu</label>' +
        '<input type="tel" name="buyerPhone" class="form-input" placeholder="+255 700 000 000" required>' +
        '</div>' +
        '<div class="form-group">' +
        '<label class="form-label"><i class="fa-solid fa-location-dot"></i> Eneo Lako</label>' +
        '<input type="text" name="buyerLocation" class="form-input" placeholder="Mfano: Kirumba, Mwanza" required>' +
        '</div>' +
        '<div class="form-row">' +
        '<div class="form-group">' +
        '<label class="form-label"><i class="fa-solid fa-hashtag"></i> Idadi</label>' +
        '<input type="number" name="buyerQty" class="form-input" value="1" min="1" required>' +
        '</div>' +
        '<div class="form-group">' +
        '<label class="form-label"><i class="fa-solid fa-calculator"></i> Jumla</label>' +
        '<input type="text" class="form-input" value="' + escapeHTML(p.price) + '" readonly style="background:#f0fdf4;color:#10b981;font-weight:800;">' +
        '</div>' +
        '</div>' +
        '<button type="submit" class="btn-submit" id="orderSubmitBtn">' +
        '<i class="fa-solid fa-paper-plane"></i> Tuma Oda' +
        '</button>' +
        '</form>';
    
    // ⭐ Attach form listener
    const form = $("orderForm");
    if (form) {
        form.addEventListener('submit', function(e) {
            submitOrder(e, p.id);
        });
    }
    
    $("modalOverlay").classList.add("active");
    document.body.style.overflow = "hidden";
}
/* ============================================================
   SUBMIT ORDER
   ============================================================ */
   async function submitOrder(e, productId) {
    e.preventDefault();
    
    // ⭐ ZUIA DOUBLE-CLICK
    const submitBtn = e.target.querySelector('button[type="submit"]');
    if (submitBtn) {
        if (submitBtn.disabled) return; // ⭐ Kama disabled, acha
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.6';
        submitBtn.style.cursor = 'wait';
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Inatuma...';
    }
    
    const form = e.target;
    const product = SokoDB.getProducts().find(p => p.id === productId);
    
    if (!product) {
        showToast("Bidhaa haipatikani!", "error");
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tuma Oda';
        }
        return;
    }
    
    // ⭐ CHECK STOCK
    const stock = parseInt(product.stock) || 0;
    if (stock <= 0) {
        showToast("Bidhaa hii imeisha! Haipatikani.", "error");
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tuma Oda';
        }
        return;
    }
    
    const qty = Number(form.buyerQty.value) || 1;
    if (qty > stock) {
        showToast(`Stock iliyopo ni ${stock} tu!`, "error");
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tuma Oda';
        }
        return;
    }
    
    const order = {
        productId: productId,
        productName: product.name,
        price: product.price,
        priceVal: product.priceVal || 0,
        quantity: qty,
        
        buyerEmail: 'guest_' + Date.now() + '@sokochap.guest',
        buyerName: form.buyerName.value.trim() || 'Mgeni',
        buyerPhone: form.buyerPhone.value.trim() || '—',
        buyerLocation: form.buyerLocation.value.trim() || '—',
        buyerAvatar: '',
        isGuest: true,
        
        seller: product.seller,
        sellerEmail: product.sellerEmail || "",
        sellerPhone: product.sellerPhone || "",
        sellerWhatsapp: product.sellerWhatsapp || product.sellerPhone || "",
        
        description: (formData.get('reqDesc') || '').trim(),
        date: new Date().toLocaleDateString('sw-TZ', { day: '2-digit', month: 'short', year: 'numeric' }),
        dateISO: new Date().toISOString(),
        status: "Imewekwa (Pending)"
    };
    
    try {
        await SokoDB.saveOrder(order);
        showToast(`Oda yako ya "${product.name}" imetumwa kwa ${product.seller}!`, "success");
        form.reset();
        closeModal();
    } catch (err) {
        console.error(err);
        showToast("Imeshindwa kutuma: " + err.message, "error");
        
        // ⭐ Rudisha button kama error
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tuma Oda';
        }
    }
}
   
   
   
/* ============================================================
   CLOSE MODAL
   ============================================================ */
function closeModal() {
    $("modalOverlay").classList.remove("active");
    document.body.style.overflow = "";
}

/* ============================================================
   MAKE ORDER (Ombi la Bidhaa)
   ============================================================ */
function openMakeOrder() {
    $("modalPanel").innerHTML =
        '<div class="modal-handle"></div>' +
        '<div class="modal-header">' +
            '<span class="modal-title"><i class="fa-solid fa-bullhorn" style="color:#0ea5e9;"></i> Weka Ombi la Bidhaa</span>' +
            '<button class="modal-close" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
        '</div>' +
        '<p style="font-size:12px;color:#64748b;margin-bottom:18px;line-height:1.6;">Ukiwa unatafuta bidhaa ambayo haipo sokoni, jaza fomu hii ili wauzaji waione.</p>' +
        '<form id="requestForm">' +
            '<div class="form-group">' +
                '<label class="form-label"><i class="fa-solid fa-box"></i> Bidhaa Unayotafuta</label>' +
                '<input type="text" name="reqName" class="form-input" placeholder="Mfano: Laptop HP Core i5" required>' +
            '</div>' +
            '<div class="form-row">' +
                '<div class="form-group">' +
                    '<label class="form-label"><i class="fa-solid fa-money-bill-wave"></i> Bei</label>' +
                    '<input type="text" name="reqPrice" class="form-input" placeholder="TZS 500,000" required>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label class="form-label"><i class="fa-solid fa-hashtag"></i> Idadi</label>' +
                    '<input type="number" name="reqQty" class="form-input" value="1" min="1" required>' +
                '</div>' +
            '</div>' +
            '<div class="form-group">' +
                '<label class="form-label"><i class="fa-solid fa-user"></i> Jina Lako</label>' +
                '<input type="text" name="reqBuyer" class="form-input" placeholder="Jina lako kamili" required>' +
            '</div>' +
            '<div class="form-group">' +
                '<label class="form-label"><i class="fa-solid fa-phone"></i> Namba ya Simu</label>' +
                '<input type="tel" name="reqPhone" class="form-input" placeholder="+255 700 000 000" required>' +
            '</div>' +
            '<div class="form-group">' +
                '<label class="form-label"><i class="fa-solid fa-location-dot"></i> Eneo Lako</label>' +
                '<input type="text" name="reqLocation" class="form-input" placeholder="Mfano: Kirumba, Mwanza" required>' +
            '</div>' +
            '<div class="form-group">' +
                '<label class="form-label"><i class="fa-solid fa-align-left"></i> Maelezo (Optional)</label>' +
                '<textarea name="reqDesc" class="form-input" rows="2" placeholder="Eleza bidhaa unayotaka — rangi, size, brand, hali..."></textarea>' +
            '</div>' +
            '<button type="submit" class="btn-submit"><i class="fa-solid fa-paper-plane"></i> Tuma Ombi</button>' +
        '</form>';
    
    const form = $("requestForm");
    if (form) {
        form.addEventListener('submit', submitRequest);
    }
    
    $("modalOverlay").classList.add("active");
    document.body.style.overflow = "hidden";
}

/* ============================================================
   SUBMIT REQUEST
   ============================================================ */
async function submitRequest(e) {
    e.preventDefault();
    
    // ⭐ ZUIA DOUBLE-CLICK
    const submitBtn = e.target.querySelector('button[type="submit"]');
    if (submitBtn) {
        if (submitBtn.disabled) return;
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.6';
        submitBtn.style.cursor = 'wait';
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Inatuma...';
    }
    
    const form = e.target;
    const formData = new FormData(form);
    const guestId = 'guest_' + Date.now();
    
    const req = {
        name: (formData.get('reqName') || '').trim(),
        category: "Ombi",
        condition: "Mpya",
        quantity: Number(formData.get('reqQty')) || 1,
        budget: (formData.get('reqPrice') || '').trim(),
        
        phone: (formData.get('reqPhone') || '').trim(),
        whatsapp: (formData.get('reqPhone') || '').trim(),
        location: (formData.get('reqLocation') || '').trim(),
        
        buyer: (formData.get('reqBuyer') || '').trim() || 'Mgeni',
        buyerName: (formData.get('reqBuyer') || '').trim() || 'Mgeni',
        buyerEmail: guestId + '@sokochap.guest',
        buyerAvatar: '',
        isGuest: true,
        status: 'Open',
        
        date: new Date().toLocaleDateString('sw-TZ', { day: '2-digit', month: 'short', year: 'numeric' })
    };
    
    try {
        await SokoDB.saveRequest(req);
        closeModal();
        showToast("Ombi lako limepokelewa! Wauzaji watawasiliana nawe.", "success");
    } catch (err) {
        console.error(err);
        showToast("Imeshindwa kutuma: " + err.message, "error");
        
        // ⭐ Rudisha button kama error
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tuma Ombi';
        }
    }
}



/* ============================================================
   SCROLL EVENT
   ============================================================ */
window.addEventListener('scroll', function() {
    const header = $('stickyHeader');
    if (!header) return;
    if (window.scrollY > 10) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

/* ============================================================
   SEARCH
   ============================================================ */
const searchInput = $("searchInput");
if (searchInput) {
    searchInput.addEventListener("input", function(e) {
        const q = e.target.value.toLowerCase().trim();
        if (!q) {
            renderFeed();
            return;
        }
        const filtered = SokoDB.getProducts().filter(function(p) {
            return (p.name || "").toLowerCase().includes(q) ||
                (p.seller || "").toLowerCase().includes(q) ||
                (p.category || "").toLowerCase().includes(q) ||
                (p.sellerLocation || "").toLowerCase().includes(q);
        });
        renderFeed(filtered);
    });
}

/* ============================================================
   MODAL OVERLAY CLICK — Funga
   ============================================================ */
const modalOverlay = $("modalOverlay");
if (modalOverlay) {
    modalOverlay.addEventListener("click", function(e) {
        if (e.target.id === "modalOverlay") closeModal();
    });
}

/* ============================================================
   INIT
   ============================================================ */
/* ⭐ Subiri data ipakiwe kabla ya render */
window.addEventListener('sokoDataReady', function() {
    console.log('✅ index.html: Data ready');
    renderFeed();
});

window.addEventListener('sokoDataError', function() {
    console.error('❌ Data loading failed');
    const feed = document.getElementById('productFeed');
    if (feed) {
        feed.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#ef4444;"><i class="fa-solid fa-exclamation-triangle" style="font-size:48px;margin-bottom:12px;display:block;"></i><p>Imeshindwa kupakia data. Refresh page.</p></div>';
    }
});;